# TarzAI
"TarzAI" ini belum canggih mungkin saya ada waktu untuk membuat API sendiri mungkin berapa tahun lagi, ini sangat sulit bagi saya sendiri. yah semoga saya bisa.

## Fitur:
- [x] Saya bisa membalas chat anda

- [ ] Saya bisa generate code
 
- [ ] Saya bisa membuat gambar

- [x] Saya akurat dalam konteks

- [x] Saya bisa membantu anda

- [x] Bisa Membantu anda

- [ ] Pembaruan API

- [x] Watermark

Menggunakan API	               : Gemini/Google
## Info:
Saya ingin mengajak teman siapapun itu, kalo mau chat wa saya 

WhatsApp: [Chat](https://wa.me/message/UYPM2Q2UEML2C1)

Telegram: [Chat](https://t.me/TarnaWijaya)
